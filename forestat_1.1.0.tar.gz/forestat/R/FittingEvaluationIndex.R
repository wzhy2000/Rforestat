#' Calculate Fitting Evaluation Index
#'
#' This function calculates several fitting evaluation indices based on 
#' estimated and observed values.
#'
#' @param EstiH A numeric vector of estimated values.
#' @param ObsH A numeric vector of observed values.
#' @return A named vector with evaluation indices:
#' \describe{
#'   \item{pe}{Mean error}
#'   \item{RMSE}{Root Mean Squared Error}
#'   \item{R2}{Coefficient of determination}
#'   \item{Var}{Variance of the error}
#'   \item{TRE}{Total Relative Error (percentage)}
#'   \item{sd}{Standard deviation of error}
#' }
#' @export
FittingEvaluationIndex <- function(EstiH, ObsH) {
  Index <- array(dim = 6)
  e <- ObsH - EstiH
  e1 <- ObsH - mean(ObsH)
  pe <- mean(e)
  var2 <- var(e)
  var <- sqrt(var(e))
  RMSE <- sqrt(pe ^ 2 + var2)
  R2 <- 1 - sum(e ^ 2) / sum((e1) ^ 2)
  TRE <- 100 * sum(e ^ 2) / sum((EstiH) ^ 2)
  Index[1] <- pe
  Index[2] <- RMSE
  Index[3] <- R2
  Index[4] <- var2
  Index[5] <- TRE
  Index[6] <- var
  dimnames(Index) <- list(c("pe", "RMSE", "R2", "Var", "TRE", "sd"))
  return(Index)
}
